package com.swiggy.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.swiggy.model.Cart;
import com.swiggy.model.Food;
import com.swiggy.service.SwiggyService;

import io.jsonwebtoken.Jwts;

@RestController
@CrossOrigin

public class SwiggyController {

	@Autowired
	SwiggyService service;

	@RequestMapping(value = "/")
	public String addItem() {
		//service.addFoodItem();
		return "abcd";
	}

	@GetMapping(value = "getFoodItems", produces = "application/json")
	public List<Food> getFoodList(HttpServletRequest request  ) {
		List<Food> foodList = service.getFoodList();
		return foodList;
	}

	@GetMapping(value = "getCartItems", produces = "application/json")
	public List<Cart> getCartList(HttpServletRequest request) {
		String userId=getUserid(request);
		List<Cart> cartList = service.getCartList(userId);
		return cartList;
	}

	@PostMapping(value = "add")
	public ResponseEntity<String> addtoCart(@RequestBody Food food,HttpServletRequest request) {
		String userId=getUserid(request);
		ResponseEntity<String> responseEntity;
		String response="";
		String name = food.getName();

		if (!service.nameExistsInCart(name,userId)) {
			service.addToCart(food,userId);
			
			response="Added to cart";
		} else {
			service.updateCart(food,userId);
		
			response="cart Updated";
		}

		responseEntity = new ResponseEntity<String>(response, HttpStatus.OK);
		return responseEntity;

	}

	@GetMapping(value = "totalCost")
	public int getTotalCost(HttpServletRequest request) {
		String userId=getUserid(request);
		int price = service.getTotalCost(userId);
		
		
		return price;
	}

	@PostMapping(value = "delete")
	public ResponseEntity<String> deleteFromCart(@RequestBody Cart cart,HttpServletRequest request) {
		String userId=getUserid(request);
		ResponseEntity<String> responseEntity;
		String response="";
		service.deleteFromCart(cart,userId);
		response="Removed from Cart";
		responseEntity = new ResponseEntity<String>(response, HttpStatus.OK);
		return responseEntity;
	}
	
	@PostMapping(value = "placeOrder")
	public ResponseEntity<Map<String, String>> placeOrder(HttpServletRequest request)
	{
		String userId=getUserid(request);
		ResponseEntity<Map<String, String>> responseEntity;
		Map<String, String> map1 = new HashMap<>();
		service.placeOrder(userId);
		map1.put("message","Your Order has been placed Successfully");
		responseEntity = new ResponseEntity<Map<String, String>>(map1, HttpStatus.OK);
		return responseEntity;
		
		
	}
	
	private String getUserid(HttpServletRequest request)
	{
		final String authHeader=(request.getHeader("Authorization"));
		final String token=authHeader.substring(7);
		String userId = Jwts.parser().setSigningKey("secretkey").parseClaimsJws(token).getBody().getSubject();
		return userId;
	}
	

}
