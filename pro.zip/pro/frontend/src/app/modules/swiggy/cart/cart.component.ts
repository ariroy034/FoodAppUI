import { Component, OnInit } from '@angular/core';
import { SwiggyServiceService } from '../swiggy-service.service';
import {Cart} from '../cart';
import { Router } from '@angular/router';
@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
cartitems:Array<any>;
cost:Number;
cart:Cart;
price:any;
inputNumber:Array<Number>;
quantity:any;
singlePrice:any;
size:any;
quan:any;

  constructor(private cartservice: SwiggyServiceService,private router:Router) {
    this.inputNumber=new Array<Number>();
   }

  ngOnInit() {
    this.cartservice.getCartItems().subscribe(data => {
      this.cartitems = data;
      this.size=this.cartitems.length;
    });
    this.cartservice.getTotalCost().subscribe(tcost => {
      this.cost = tcost;
    });
  }

removeFromCart(cart)
{
  this.quantity=this.inputNumber[cart.id];
  this.price=cart.price;
  this.singlePrice=this.price/cart.quantity;
  cart.quantity=cart.quantity-this.quantity;
  cart.price=cart.quantity*this.singlePrice;
 
  console.log(cart);
  this.cartservice.deleteFromCart(cart).subscribe(data=>{
 console.log(data);
   this.ngOnInit();
   console.log(this.cost);
 
 });
 
}

placeOrder()
{
  this.cartservice.placeOrder().subscribe(data=>{
    console.log(data);
    this.router.navigate(['/orderplaced']);   
    });
}

disableButton(cart)
{
  this.quan=this.inputNumber[cart.id];
  if(this.quan>0)
  return true;
  else
  return false;


}






}
