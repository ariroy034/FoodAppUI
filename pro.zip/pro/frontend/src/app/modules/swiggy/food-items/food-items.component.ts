import { Component, OnInit } from '@angular/core';
import { SwiggyServiceService } from '../swiggy-service.service';
import {Food} from '../food';

@Component({
  selector: 'app-food-items',
  templateUrl: './food-items.component.html',
  styleUrls: ['./food-items.component.css']
})
export class FoodItemsComponent implements OnInit {
  fooditems: Array<any>;
  food:Food;
  quantity:any;
  inputNumber:Array<Number>;
  
  constructor(private foodservice: SwiggyServiceService) {
    this.inputNumber=new Array<Number>();
   }

  ngOnInit() {
    this.foodservice.getFoodItems().subscribe(data => {
      this.fooditems = data;
    });
  }
addtoCart(food)
{
 this.quantity=this.inputNumber[food.id];
 food.quantity=food.quantity-this.quantity;
 this.foodservice.addtoCart(food).subscribe(data=>{
 alert(data);
 });

}


}
