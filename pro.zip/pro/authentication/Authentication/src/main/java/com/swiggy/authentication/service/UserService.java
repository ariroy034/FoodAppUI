package com.swiggy.authentication.service;

import com.swiggy.authentication.model.User;

public interface UserService {
	boolean saveUser(User user);

	User findByUserIdAndPassword(String userName, String password);

	boolean checkUsernameAvaibility(User user);

}
