package com.swiggy.authentication.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.swiggy.authentication.model.User;
import com.swiggy.authentication.repository.UserRepository;

@Service("userService")
public class UserServiceImpl implements UserService {

	@Autowired
	UserRepository userRepository;

	public boolean saveUser(User user) {
		boolean result=false;
		try {
			User existingUser = userRepository.findbyUsername(user.getUserName());			
			if(existingUser==null)
			{
				userRepository.save(user);
				result=true;
			}
		}
		catch (NullPointerException e) {
			
			
		}
		return result;
	}

	public User findByUserIdAndPassword(String userName, String password) {
		System.out.println("firsthere");
		User user = userRepository.findByUserIdAndPassword(userName, password).orElse(null);
		System.out.println(user);
		System.out.println("here");
		if (user == null) {
			return null;
		}
		return user;

	}

	@Override
	public boolean checkUsernameAvaibility(User user) {
		boolean result=false;
		User existingUser = userRepository.findbyUsername(user.getUserName().trim());	
		if(existingUser==null)
		{
			result=true;
		}
		return result;
	}

}
