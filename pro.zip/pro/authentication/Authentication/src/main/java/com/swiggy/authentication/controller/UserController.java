package com.swiggy.authentication.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.swiggy.authentication.model.User;
import com.swiggy.authentication.service.JwtSecurityTokenGenerator;
import com.swiggy.authentication.service.UserService;

@RestController
@CrossOrigin
@RequestMapping("/auth")
public class UserController {

	@Autowired
	UserService userService;

	@Autowired
	JwtSecurityTokenGenerator generator;

	@PostMapping("/register")
	public ResponseEntity<Map<String,String>> registerUser(@RequestBody User user) {
		//System.out.println(user.getPhoneNumber());
		Map<String,String> map=new HashMap<String, String>();
		if (userService.saveUser(user)) {
			map.put("message","User registered successfully");
			return new ResponseEntity<Map<String,String>>(map, HttpStatus.CREATED);
		} else {
			map.put("message","User already exists with this ID");
			return new ResponseEntity<Map<String,String>>(map, HttpStatus.CONFLICT);
		}

	}

	@PostMapping("/login")
	public ResponseEntity<Map<String, String>> login(@RequestBody User loginDetail) {
		User user = userService.findByUserIdAndPassword(loginDetail.getUserName(), loginDetail.getPassword());
		if(user==null){
			Map<String, String> map =new HashMap<String, String>();
			map.put("response", "Invalid Credentials");
			System.out.println(map);
			return new ResponseEntity<Map<String, String>>(map,HttpStatus.OK);
		}
		else{
		Map<String, String> map = generator.generateToken(user);
		
		return new ResponseEntity<Map<String, String>>(map, HttpStatus.OK);
		}

	}

	@PostMapping("/checkUser")
	public ResponseEntity<String> checkUser(@RequestBody User user)
	{
		boolean result=userService.checkUsernameAvaibility(user);
		if(!result)
		{
			String response="User already exists";
			return new ResponseEntity<String>(response, HttpStatus.OK);
		}
		else
		{
			String response="New User";
			return new ResponseEntity<String>(response, HttpStatus.OK);
		}
	}
}
