package com.foodapp.controller;

import java.util.List;


import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.foodapp.service.FoodAppService;

import io.jsonwebtoken.Jwts;

import com.foodapp.model.*;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class FoodAppController {
	@Autowired
	FoodAppService service;
	//@CrossOrigin(origins="http://localhost:4200")
	@RequestMapping(value="/")
	public String addItem(){
		return "ok";
	}
	//@CrossOrigin(origins="http://localhost:4200")
	@GetMapping(value="getFoodItems")
	public List<Item> getFoodList(HttpServletRequest request  ) {
		List<Item> foodList = service.getItemList();
		return foodList;
	}
	
	@PostMapping(value = "add")
	//@CrossOrigin(origins="http://localhost:4200")
	public ResponseEntity<String> addtoCart(@RequestBody Item item,HttpServletRequest request) {
		String userId=getUserid(request);
		String response="";
		service.addToCart(item, userId);
		response="Added";
		return new ResponseEntity<String>(response,HttpStatus.OK);
		}
	//@CrossOrigin(origins="http://localhost:4200")
	@GetMapping(value="getCartItems")
	public List<Item> getCartItems(HttpServletRequest request) {
		String id=getUserid(request);
		List<Item> set=service.getCartItems(id);
		//String userId=id;
		return set;
	}
	@GetMapping(value="totalCost")
	//@CrossOrigin(origins="http://localhost:4200")
	public int getTotalCost(HttpServletRequest request){
		String id = getUserid(request);
		int price=service.getTotalCost(id);
		return price;
	}
	
	//@CrossOrigin(origins = "http://localhost:4200")
	private String getUserid(HttpServletRequest request) {
		final String authHeader = (request.getHeader("Authorization"));
		final String token = authHeader.substring(7);
		String userId = Jwts.parser().setSigningKey("secretkey").parseClaimsJws(token).getBody().getSubject();
		//log.debug(userId);
		return userId;
	}
	
	@PostMapping(value="deleteFromCart")
	//@CrossOrigin(origins="http://localhost:4200")
	public  ResponseEntity<String> deleteFromCart(@RequestBody Item item,HttpServletRequest request) {
		String userId=getUserid(request);
		System.out.println(item.getId());
		service.deleteFromCart(item, userId);
		System.out.println("deleted");
		String response="Deleted";
		return new ResponseEntity<String>(response,HttpStatus.OK);
		}

}
