package com.foodapp.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foodapp.model.Cart;
import com.foodapp.model.Item;
import com.foodapp.model.User;
import com.foodapp.repository.CartRepository;
import com.foodapp.repository.ItemRepository;
import com.foodapp.repository.UserRepository;



@Service("service")
public class FoodAppServiceImpl implements FoodAppService{

	@Autowired
	ItemRepository itemRepository;

	@Autowired
	CartRepository cartRepository;
	
	@Autowired
	UserRepository userRepository;
	
	@Transactional
	public List<Item> getItemList() {
		List<Item> itemList=(List<Item>) itemRepository.findAll();
		return itemList;
	}


	@Override
	public Item getItemByid(int id) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	@Transactional
	public void addToCart(Item item, String userId) {
		//System.out.println(item.getQuantity());
		int id = item.getId();
		Item oldItem = itemRepository.findOne(id);
		Cart cart = cartRepository.findByUserId(userId).orElse(null);
		if (cart == null) {
			Cart cartNew = new Cart();
			cartNew.setUserId(userId);
			Map<Item, Integer> cartFood = cartNew.getItems();
			cartFood.put(oldItem, item.getQuantity());
			cartRepository.save(cartNew);
		} else {
			Map<Item, Integer> cartFood = cart.getItems();
			cartFood.put(oldItem, item.getQuantity());
			cartRepository.save(cart);
		}
		oldItem.setQuantity(oldItem.getQuantity() - item.getQuantity());
		itemRepository.save(oldItem);

	}



	@Override
	public void updateCart(Item item, String userId) {
		// TODO Auto-generated method stub
		
	}

	@Transactional
	public int getTotalCost(String userId) {
		int price = 0;

		Cart cart = cartRepository.findByUserId(userId).orElse(null);
		if (cart == null) {
			return 0;
		}
		Map<Item, Integer> cartFood = cart.getItems();
		for (Map.Entry<Item, Integer> entry : cartFood.entrySet()) {
			price = price + (entry.getKey().getPrice() * entry.getValue());
		}

		return price;

	}

	@Transactional
	@Override
	public void deleteFromCart(Item item, String userId) {
		Cart cart = cartRepository.findByUserId(userId).orElse(null);
		for(Map.Entry<Item,Integer> entry: cart.getItems().entrySet()){
			if(entry.getKey().getName().equals(item.getName())){
				cart.getItems().remove(item);
			}
		}
		cartRepository.save(cart);
			
	}

	@Transactional
	@Override
	public void placeOrder(String userId) {
		Cart cart = cartRepository.findByUserId(userId).orElse(null);
		cart.setItems(null);
		cartRepository.save(cart);
	}


	@Override
	@Transactional
	public List<Item> getCartItems(String userId) {
		List<Item> foodList = new ArrayList<Item>();
		Cart cart = cartRepository.findByUserId(userId).orElse(null);
		if (cart == null) {
			return null;
		} else {
			System.out.println(cart.getItems());
			Map<Item, Integer> cartFood = cart.getItems();
			for (Map.Entry<Item, Integer> entry : cartFood.entrySet()) {
				Item item = new Item();
				item.setQuantity(entry.getValue());
				item.setPrice(entry.getValue() * entry.getKey().getPrice());
				item.setName(entry.getKey().getName());
				item.setDescription(entry.getKey().getDescription());
				item.setImage(entry.getKey().getImage());
				item.setId(entry.getKey().getId());
				foodList.add(item);
				System.out.println(entry.getKey().getId());
			}
		}
		return foodList;

	}



}

//	@Override
//	public void updateCart(Item item, String userId) {
//		User user = userRepository.findOne(userId);
//		for(Item i:user.getCart().getItems()){
//			if(i.getName().equalsIgnoreCase(item.getName()))
//				i.setQuantity(item.getQuantity());
//		}
//		
//		
//	}
//
//
//	@Override
//	public int getTotalCost(String userId) {
//		User user = userRepository.findOne(userId);
//		int totalCost=0;
//		for(Item i:user.getCart().getItems()){
//			totalCost=totalCost+i.getPrice();
//		}
//		return totalCost;
//	}
//
//
//	@Override
//	public void deleteFromCart(Item item, String userId) {
//		User user = userRepository.findOne(userId);
//		for(Item i:user.getCart().getItems()){
//			if(i.getName().equalsIgnoreCase(item.getName()))
//				user.getCart().getItems().remove(i);
//		}
//			
//		
//	}
//
//
//	@Override
//	public void placeOrder(String userId) {
//		User user = userRepository.findOne(userId);
//		user.getCart().getItems().removeAll(user.getCart().getItems());
//		
//	}


