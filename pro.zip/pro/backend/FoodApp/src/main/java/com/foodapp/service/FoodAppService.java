package com.foodapp.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.foodapp.model.Cart;
import com.foodapp.model.Item;


public interface FoodAppService {
	public List<Item> getItemList();
	public Item getItemByid(int id);
	public void addToCart(Item item,String userId);
	public void updateCart(Item item, String userId);
	public int getTotalCost(String userId);
	public void deleteFromCart(Item item, String userId);
	public void placeOrder(String userId);
	public List<Item> getCartItems(String userId);
}
